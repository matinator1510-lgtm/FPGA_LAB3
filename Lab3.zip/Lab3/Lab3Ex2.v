module Lab1(input clk, key1,
            output reg [7:0] seg,
            output [3:0] dig);

// Debouncing variables
reg [19:0] debounce_cnt = 0; // 20-bit counter to reach 1,000,000
reg clean_key = 1;           // Holds the stabilized button state

reg [3:0] n = 0;
reg old = 1;

assign dig = 4'b1110;        // one digit ON

// 1. Debounce Logic
always @(posedge clk) begin
    if (key1 == clean_key) begin
        debounce_cnt <= 0;   // Signal hasn't changed, reset counter
    end else begin
        debounce_cnt <= debounce_cnt + 1; // Signal changed, start timing
        
        // If 20ms has passed with the signal remaining different
        if (debounce_cnt == 20'd1000000) begin 
            clean_key <= key1; // Accept the new, stable state
            debounce_cnt <= 0;
        end
    end
end

// 2. Edge detection and digit counter (using clean_key instead of key1)
always @(posedge clk) begin
    old <= clean_key; 
    if (old & ~clean_key) n <= (n==9) ? 0 : n+1;
end

// 3. 7-Segment Decoder
always @* begin
    case(n)
        0: seg = 8'hC0;   1: seg = 8'hF9;
        2: seg = 8'hA4;   3: seg = 8'hB0;
        4: seg = 8'h99;   5: seg = 8'h92;
        6: seg = 8'h82;   7: seg = 8'hF8;
        8: seg = 8'h80;   9: seg = 8'h90;
        default: seg = 8'hFF; // Fixes the Quartus Latch warnings
    endcase
end

endmodule